#include "LocStatsItem.h"
#include "Game.h"

Game::Game() {

}

Game::~Game() {

}